# Header ------------------------------------------------------------------

# File Name: 	  	  Callahan_Project1_Script
# File Purpose:  	  R code for Project 1
# Author: 	    	  Anna Callahan (University of Pennsylvania)
# Date Created:     2020/06/30
# Notes:            Data is from openICPSR

# Version Log:      
# Version           Date          Notes
# 1.0               2020/06/30    Created


# Install Packages & WD ---------------------------------------------------

suppressMessages(library("tidyverse"))
suppressMessages(library("reshape2"))
suppressMessages(library("corrplot"))
suppressMessages(library("foreign"))
suppressMessages(library("forcats"))

#get wd
getwd()

# set wd
setwd("/Users/annacallahan/Documents/Intro to Data Science/Project")

# Data Cleaning ---------------------------------------------------

#read in spss file for DEBATE 1
dta1 = read.spss("Debate1DataR2.sav", to.data.frame = TRUE)

# Examine data
dim(dta1) # 175 x 265
glimpse(dta1)
view(dta1)

# I only want the debate group, not the control group
# Basically, I need to chop the df in half - I only want rows 1-89
dta1 <- dta1[-c(90:175),]
view(dta1) # check - all good!
dim(dta1) #89 x 265

# Now, I only need to examine my pre-selected variables
# so I'm only keeping the following columns:
# Pre1,Pre3,Pre4,Pre5,Pre6,Pre12,Pre13,Pre15,Pre29,Pre30,Pre31,Pre33,Pre34,Pre35,Pre48,Pre49,Pre50,Pre51,Pre52,Pre53,Pre54,Pre55,Pre96,Pre97,Post7,Post12,Post13,Post9,Post10,Post4,Post26,Post27,Post28,Post22,Post23,Post24,Post40,Post41,Post42,Post43,Post44,Post45,Post46
dta1_dropped = subset(dta1, select = c(Pre1,Pre3,Pre4,Pre5,Pre6,Pre12,Pre13,Pre15,Pre29,Pre30,Pre31,Pre33,Pre34,Pre35,Pre48,Pre49,Pre50,Pre51,Pre52,Pre53,Pre54,Pre55,Pre96,Pre97,Post7,Post12,Post13,Post9,Post10,Post4,Post26,Post27,Post28,Post22,Post23,Post24,Post40,Post41,Post42,Post43,Post44,Post45,Post46,Post47))
dim(dta1_dropped) # 89 x 44

# Rename
df <- dta1_dropped

# Here are the current columns
colnames(df)

# Give the columns more intuitive names using dplyr
df <- df %>% 
  rename(interest = Pre1, 
         pre_pref = Pre3,
         party = Pre4,
         pre_tone_trump = Pre5,
         pre_tone_clinton = Pre6,
         pre_warmth_clinton = Pre12,
         pre_warmth_trump = Pre13,
         pre_winner = Pre15,
         pre_trump_econ = Pre29,
         pre_trump_healthcare = Pre30,
         pre_trump_terror = Pre31,
         pre_clinton_econ = Pre33,
         pre_clinton_healthcare = Pre34,
         pre_clinton_terror = Pre35,
         pre_clinton_honesty = Pre48,
         pre_clinton_knowledge = Pre49,
         pre_clinton_empathy = Pre50,
         pre_clinton_leader = Pre51,
         pre_trump_honesty = Pre52,
         pre_trump_knowledge = Pre53,
         pre_trump_empathy = Pre54,
         pre_trump_leader = Pre55,
         age = Pre96,
         gender = Pre97,
         post_pref = Post7,
         post_tone_trump = Post12,
         post_tone_clinton = Post13,
         post_warmth_clinton = Post9,
         post_warmth_trump = Post10,
         post_winner = Post4,
         post_trump_econ = Post26,
         post_trump_healthcare = Post27,
         post_trump_terror = Post28,
         post_clinton_econ = Post22,
         post_clinton_healthcare = Post23,
         post_clinton_terror = Post24,
         post_clinton_honesty = Post40,
         post_clinton_knowledge = Post41,
         post_clinton_empathy = Post42,
         post_clinton_leader = Post43,
         post_trump_honesty = Post44,
         post_trump_knowledge = Post45,
         post_trump_empathy = Post46,
         post_trump_leader = Post47)
colnames(df)

# Create an id column
df$id <- 1:nrow(df)



# Exploratory Data Analysis ---------------------------------------------------

# TONE

# How did the average man’s perception of Clinton’s “tone” change after the debate?
# Step 1. Create a factor variable for the pre tone Clinton column
df$pre_tone_clinton # there is an error in the df - fix it
levels(df$pre_tone_clinton) # collapse down into positive, negative, and null
df$pre_tone_clinton_pos_neg <- 
  df$pre_tone_clinton %>%
  fct_collapse(Negative=c("somewhat negative","very negative"),
               Positive=c("Very Positive","Somewhat Positive"),
               Neither=c("don't know","9","Mixture of positive and negative"))

levels(df$pre_tone_clinton_pos_neg)

# Respondent with id # 31 did not answer a bunch of qs so I'm dropping the row
dim(df) # 89 x 47
df <- df[-c(31),]
dim(df) # 88 x 47
# view(df) # row where id was 32 was successfully dropped :) 

# Now calculate the number of males who viewed Clinton negatively before the debate
# Create a table of the male respondents
df$gender
male_df <- df[which(df$gender=="male"),]
male_df$gender #check - it worked!

male_pos <- nrow(male_df[which(male_df$pre_tone_clinton_pos_neg=="Positive"),])
male_neg <- nrow(male_df[which(male_df$pre_tone_clinton_pos_neg=="Negative"),])
male_na <- nrow(male_df[which(male_df$pre_tone_clinton_pos_neg=="Neither"),])

# 2. Create a factor variable for the POST tone Clinton column
df$post_tone_clinton # there is an error in the df - fix it
levels(df$post_tone_clinton) # collapse down into positive, negative, and null
df$post_tone_clinton_pos_neg <- 
  df$post_tone_clinton %>%
  fct_collapse(Negative=c("somewhat negative","very negative"),
               Positive=c("Very Positive","Somewhat Positive"),
               Neither=c("don't know","9","Mixture of positive and negative"))

levels(df$post_tone_clinton_pos_neg)

# Calculate the percent of males

male_df <- df[which(df$gender=="male"),]
male_df$gender #check - it worked!

male_pos_post <- nrow(male_df[which(male_df$post_tone_clinton_pos_neg=="Positive"),])
male_neg_post <- nrow(male_df[which(male_df$post_tone_clinton_pos_neg=="Negative"),])
male_na_post <- nrow(male_df[which(male_df$post_tone_clinton_pos_neg=="Neither"),])

# Now add these values to a table
survey <- c("pre-debate","post-debate")
positive <- c(male_pos,male_pos_post)
negative <- c(male_neg,male_neg_post)
neutral <- c(male_na,male_na_post)
male_result <- data.frame(survey,positive,negative,neutral)

# Now do the same thing, with women (!) copy and paste code from above
df$gender
female_df <- df[which(df$gender=="female"),]
female_df$gender #check - it worked!
# view(female_df)

female_pos <- nrow(female_df[which(female_df$pre_tone_clinton_pos_neg=="Positive"),])
female_neg <- nrow(female_df[which(female_df$pre_tone_clinton_pos_neg=="Negative"),])
female_na <- nrow(female_df[which(female_df$pre_tone_clinton_pos_neg=="Neither"),])

female_pos_post <- nrow(female_df[which(female_df$post_tone_clinton_pos_neg=="Positive"),])
female_neg_post <- nrow(female_df[which(female_df$post_tone_clinton_pos_neg=="Negative"),])
female_na_post <- nrow(female_df[which(female_df$post_tone_clinton_pos_neg=="Neither"),])

f_positive <- c(female_pos,female_pos_post)
f_negative <- c(female_neg,female_neg_post)
f_neutral <- c(female_na,female_na_post)
female_result <- data.frame(survey,f_positive,f_negative,f_neutral)

# compare how opinion of tone changed
view(male_result)
view(female_result)

# WARMTH

# A good graph for this would be a scatter plot with a regression line !
df$pre_warmth_clinton

# First, find what type this column in
glimpse(df) # they are doubles - good!

# Find the average male response and the average female response
m_b <- round(mean(male_df$pre_warmth_clinton,na.rm=T), digits=2)
m_a <- round(mean(male_df$post_warmth_clinton,na.rm=T), digits=2)
# Males perception of Clinton's "warmth" increased by ___ points :
m_a - m_b
# Females perception of Clinton's "warmth" increased by ___ points :
f_b <- round(mean(female_df$pre_warmth_clinton,na.rm=T), digits=2)
f_a <- round(mean(female_df$post_warmth_clinton,na.rm=T), digits=2)
f_a - f_b

# Versus trump
m_b_trump <- round(mean(male_df$pre_warmth_trump,na.rm=T), digits=2)
m_a_trump <- round(mean(male_df$post_warmth_trump,na.rm=T), digits=2)
# Males perception of Trump's "warmth" changed by ___ points :
m_a_trump - m_b_trump

f_b_trump <- round(mean(female_df$pre_warmth_trump,na.rm=T), digits=2)
f_a_trump <- round(mean(female_df$post_warmth_trump,na.rm=T), digits=2)
# Females perception of Trump's "warmth" changed by ___ points :
f_a_trump - f_b_trump


# Find the median responses, pre and post debate
male_median_before_clinton <- median(male_df$pre_warmth_clinton,na.rm=T)
female_median_before_clinton <- median(female_df$pre_warmth_clinton,na.rm=T)
male_median_before_trump <- median(male_df$pre_warmth_trump,na.rm=T)
female_median_before_trump <- median(female_df$pre_warmth_trump,na.rm=T)
male_median_after_clinton <- median(male_df$post_warmth_clinton,na.rm=T)
female_median_after_clinton <- median(female_df$post_warmth_clinton,na.rm=T)
male_median_after_trump <- median(male_df$post_warmth_trump,na.rm=T)
female_median_after_trump <- median(female_df$post_warmth_trump,na.rm=T)

# Find the standard deviations
male_sd_before_clinton <- round(sd(male_df$pre_warmth_clinton), digits=2)
female_sd_before_clinton <- round(sd(female_df$pre_warmth_clinton), digits=2)
male_sd_before_trump <- round(sd(male_df$pre_warmth_trump), digits=2)
female_sd_before_trump <- round(sd(female_df$pre_warmth_trump), digits=2)
male_sd_after_clinton <- round(sd(male_df$post_warmth_clinton), digits=2)
female_sd_after_clinton <- round(sd(female_df$post_warmth_clinton), digits=2)
male_sd_after_trump <- round(sd(male_df$post_warmth_trump), digits=2)
female_sd_after_trump <- round(sd(female_df$post_warmth_trump), digits=2)

# Create a table of these insights
# ggplot likes long data
# create a vector of all of the warmth ratings

gender <- c("female","female","male","male","female","female","male","male")
survey2 <- c("pre","post","pre","post","pre","post","pre","post")
candidate <- c("clinton","clinton","clinton","clinton","trump","trump","trump","trump")
toplot <- data.frame(gender,survey2,candidate)
# view(toplot)

library(ggplot2)

# Make master table for submission
# Start with vectors and then make a table out of them 
gender_identity <- c("male","female","male","female","male","female","male","female")
survey_num <- c("pre","pre","pre","pre","post","post","post","post")
candidate_col <- c("clinton","clinton","trump","trump","clinton","clinton","trump","trump")
final <- data.frame(gender_identity,survey_num,candidate_col)
# view(final)

# Create a vector with the mean ratings
means <- c(m_b,
           f_b,
           m_b_trump,
           f_b_trump,
           m_a,
           f_a,
           m_a_trump,
           f_a_trump)

# Create a vector with the median ratings
medians <- c(male_median_before_clinton,
             female_median_before_clinton,
             male_median_before_trump,
             female_median_before_trump,
             male_median_after_clinton,
             female_median_after_clinton,
             male_median_after_trump,
             female_median_after_trump)

# Create a vector with the standard deviation ratings
stdevs <- c(male_sd_before_clinton,
            female_sd_before_clinton,
            male_sd_before_trump,
            female_sd_before_trump,
            male_sd_after_clinton,
            female_sd_after_clinton,
            male_sd_after_trump,
            female_sd_after_trump)


table_for_doc <- final %>%
  mutate(mean_warmth_rating = means,
         median_warmth_ratings = medians,
         stdev_warmth_ratings = stdevs)
view(table_for_doc)

# Now, create a table showing the change in mean warmth ratings
# Group the above table by GENDER and CANDIDATE
# First, divide into sub tables

delta_trump_pre = filter(table_for_doc,candidate_col=="trump" & 
                           survey_num=="pre")
view(delta_trump_pre)
view(delta_trump_post)
delta_trump_post = filter(table_for_doc,candidate_col=="trump" & 
                           survey_num=="post")
delta_clint_pre = filter(table_for_doc,candidate_col=="clinton"  & 
                           survey_num=="pre")
delta_clint_post = filter(table_for_doc,candidate_col=="clinton"  & 
                           survey_num=="post")

# Now, all you need to do is create a new column 
# where the value of the row is the difference btwn row x and 

master_delta_table <- data.frame(gender_id = c("male","female"))
master_delta_table$change_trump_warmth <- NA
master_delta_table$change_clinton_warmth <- NA

# Create a new column called change_trump_warmth
# IF master_delta_table$gender_id == "male" 
# THEN change_trump_warmth = delta_trump_post delta_trump_pre

# create a blank table
master_delta_table[1,2] = m_a_trump-m_b_trump
master_delta_table[2,2] = f_a_trump-f_b_trump
master_delta_table[1,3] = m_a-m_b
master_delta_table[2,3] = f_a-f_b
view(master_delta_table)


# Data Visualization : WOMEN / CLINTON / PRE ---------------------------------------------------

# Get value of Clinton's HONESTY according to WOMEN
honesty_pre = female_df[c("id","pre_clinton_honesty")]
knowledge_pre = female_df[c("id","pre_clinton_knowledge")]
leader_pre = female_df[c("id","pre_clinton_leader")]
empathy_pre = female_df[c("id","pre_clinton_empathy")]

honesty_tbl <- honesty_pre %>%
  group_by(pre_clinton_honesty) %>%
  summarise(count = n() ) %>%
  mutate(prop = round((count/sum(count))*100))
  colnames(honesty_tbl)[which(names(honesty_tbl) == "prop")] <- "honesty_percent"
  colnames(honesty_tbl)[which(names(honesty_tbl) == "pre_clinton_honesty")] <- "pre_clinton"
view(honesty_tbl)
  
knowledge_tbl <- knowledge_pre %>%
  group_by(pre_clinton_knowledge) %>%
  summarise(count = n() ) %>%
  mutate(prop = round((count/sum(count))*100))
  colnames(knowledge_tbl)[which(names(knowledge_tbl) == "prop")] <- "knowledge_percent"
  colnames(knowledge_tbl)[which(names(knowledge_tbl) == "pre_clinton_knowledge")] <- "pre_clinton"
view(knowledge_tbl)
  
leader_tbl <- leader_pre %>%
  group_by(pre_clinton_leader) %>%
  summarise(count = n() ) %>%
  mutate(prop = round((count/sum(count))*100))
  colnames(leader_tbl)[which(names(leader_tbl) == "prop")] <- "leader_percent"
  colnames(leader_tbl)[which(names(leader_tbl) == "pre_clinton_leader")] <- "pre_clinton"
view(leader_tbl)
  
empathy_tbl <- empathy_pre %>%
  group_by(pre_clinton_empathy) %>%
  summarise(count = n() ) %>%
  mutate(prop = round((count/sum(count))*100))
  colnames(empathy_tbl)[which(names(empathy_tbl) == "prop")] <- "empathy_percent"
  colnames(empathy_tbl)[which(names(empathy_tbl) == "pre_clinton_empathy")] <- "pre_clinton"
view(empathy_tbl)
  
inner1 <- merge(honesty_tbl, knowledge_tbl, by="pre_clinton")
inner2 <- merge(leader_tbl, empathy_tbl, by="pre_clinton")
merged <- merge(inner1, inner2, by="pre_clinton")
keeps <- merged[c("pre_clinton","honesty_percent","knowledge_percent","leader_percent","empathy_percent")]
clinton_women_pre <- keeps
view(clinton_women_pre)

# Pivot to long data !!!!!
merged_pivoted <- clinton_women_pre %>%
  pivot_longer(cols = ends_with("percent"),
               names_to = "Traits",
               values_to = "Percentages")
view(merged_pivoted)

# Grouped bar chart !!
ggplot(merged_pivoted, aes(fill=pre_clinton, y=Percentages, x=Traits)) + 
  geom_bar(position="stack", stat="identity") +
  # scale_fill_discrete(name = "Responses") + 
    scale_fill_manual(values=c("indianred1","olivedrab2","seagreen2","steelblue1","magenta2")) +
  scale_x_discrete(
    breaks=c("empathy_percent","honesty_percent","knowledge_percent","leader_percent"),
    labels=c("empathetic", "honest", "knowledgeable", "leader")) +
  labs(title = "Female Participants' Pre-Debate Perceptions of Hillary Clinton",
      subtitle = "Poll Question: How well does the following word describe the candidate?",
      caption = "Source: Emotional Reactions to the 2016 General Election Debates, via openicpsr.org")
  
# HYPOTHESIS TESTING ---------------------------------------------------
set.seed(19104)
options(tibble.width = Inf,scipen = 999)

# Create a change in warmth column for all women df
female_df$change_in_warmth_clinton <- female_df$post_warmth_clinton - female_df$pre_warmth_clinton

# Create a sub df for rep leaning respondents
levels(female_df$party)
rep_women_df <- filter(female_df, party=="Weak Republican" | party=="Strong Republican" | party=="Independent, leaning towards the Republican Party")

all_women_change <- mean(female_df$change_in_warmth_clinton) # 11.91304
rep_women_change <- mean(rep_women_df$change_in_warmth_clinton) # 15.375

# ALTERNATIVE HYPOTHESIS: Republican women’s perception of Clinton's debate performance likely went up LESS THAN 11.9%.
# NULL HYPOTHESIS: Women's perception of Clinton's debate performance likely went up by 11.9% across party lines. 

t.test(x = rep_women_df$change_in_warmth_clinton, # the vector of all 
       mu = all_women_change, 
       alternative = "two.sided") # if we are correct, this will 

# Done! This was fun. 
